const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '______________', // Set your MySQL root password here
    multipleStatements: true
});

const setupQueries = `
  CREATE DATABASE IF NOT EXISTS project1;
  USE project1;

  CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'user'
  );

  CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    author VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );

  -- Insert dummy user (admin)
  INSERT INTO users (username, password, role) 
  SELECT 'admin', 'admin123', 'admin'
  WHERE NOT EXISTS (SELECT * FROM users WHERE username = 'admin');

  -- Insert dummy user (test)
  INSERT INTO users (username, password, role) 
  SELECT 'test', 'test123', 'user'
  WHERE NOT EXISTS (SELECT * FROM users WHERE username = 'test');

  -- Insert a sample comment
  INSERT INTO comments (author, content)
  SELECT 'admin', 'Welcome to the vulnerable site!'
  WHERE NOT EXISTS (SELECT * FROM comments);
`;

connection.query(setupQueries, (err, results) => {
    if (err) {
        console.error('Error setting up database:', err);
    } else {
        console.log('Database setup complete.');
    }
    connection.end();
});