// Main frontend logic

document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupNavigation();
});

let currentUser = null;

async function checkAuth() {
    try {
        const response = await fetch('/api/user');
        if (response.ok) {
            const data = await response.json();
            currentUser = data.user;
        } else {
            currentUser = null;
        }
    } catch (e) {
        currentUser = null;
    }
    updateNavbar();
}

function updateNavbar() {
    const nav = document.getElementById('main-nav');
    if (!nav) return;

    if (currentUser) {
        nav.innerHTML = `
            <a href="/">Home</a>
            <a href="/comments.html">Comments</a>
            <a href="/dashboard.html">Dashboard</a>
            <a href="/admin.html">Admin Panel</a>
            <a href="#" id="logout-btn">Logout (${currentUser})</a>
        `;
        document.getElementById('logout-btn').addEventListener('click', async(e) => {
            e.preventDefault();
            await fetch('/api/logout', { method: 'POST' });
            window.location.href = '/';
        });
    } else {
        nav.innerHTML = `
            <a href="/">Home</a>
            <a href="/comments.html">Comments</a>
            <a href="/login.html">Login</a>
        `;
    }
}

function showMessage(elementId, message, isError = false) {
    const el = document.getElementById(elementId);
    if (!el) return;
    el.innerHTML = message;
    el.className = isError ? 'error-msg show' : 'success-msg show';
    setTimeout(() => {
        el.className = el.className.replace('show', '');
    }, 3000);
}