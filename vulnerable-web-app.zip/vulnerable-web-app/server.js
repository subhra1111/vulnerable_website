const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();
const port = 3000;

// Database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'subhranil@9434',
  database: 'project1',
  multipleStatements: true // Required for some SQLi payloads
});

db.connect((err) => {
  if (err) {
    console.error('Database connection failed: ' + err.stack);
    return;
  }
  console.log('Connected to database.');
});

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json()); // For handling application/json
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Routes - API Endpoints

// Helper endpoint to check auth status
app.get('/api/user', (req, res) => {
  if (req.cookies.user) {
    res.json({ user: req.cookies.user });
  } else {
    res.status(401).json({ error: 'Not logged in' });
  }
});

// VULNERABILITY 1: SQL Injection
app.post('/api/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  // INSECURE QUERY: vulnerable to SQL Injection
  // try input: ' OR 1=1 -- 
  const query = "SELECT * FROM users WHERE username = '" + username + "' AND password = '" + password + "'";
  
  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error: ' + err.message });
    }

    if (results.length > 0) {
      // Login successful
      res.cookie('user', results[0].username);
      res.json({ success: true, message: 'Logged in successfully', user: results[0].username });
    } else {
      res.status(401).json({ error: 'Invalid username or password' });
    }
  });
});

app.post('/api/logout', (req, res) => {
  res.clearCookie('user');
  res.json({ success: true });
});

// VULNERABILITY 2: Cross-Site Scripting (XSS) (Stored in DB, executed on client via innerHTML)
app.get('/api/comments', (req, res) => {
  const query = "SELECT * FROM comments ORDER BY created_at DESC";
  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

app.post('/api/comments', (req, res) => {
  const author = req.cookies.user || 'Anonymous';
  const content = req.body.content;

  // Inserting comment without sanitization
  const query = "INSERT INTO comments (author, content) VALUES (?, ?)";
  db.query(query, [author, content], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true, message: 'Comment added' });
  });
});

app.post('/api/comments/clear', (req, res) => {
  // Useful for clearing annoying persistent XSS payloads during testing
  db.query("TRUNCATE TABLE comments", (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true, message: 'Comments cleared' });
  });
});

// VULNERABILITY 3: Broken Access Control
// This route is missing authorization checks. Any user (or even unauthenticated users) can access it.
app.get('/api/admin/users', (req, res) => {
  const queryUsers = "SELECT * FROM users";
  db.query(queryUsers, (err, users) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(users);
  });
});

// Serve frontend fallback for any other route
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

